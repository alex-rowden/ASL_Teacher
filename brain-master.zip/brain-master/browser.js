// this file is the entrypoint for building a browser file with browserify

brain = require("./lib/brain");